extends Node2D

@onready var character_body_2d: CharacterBody2D = $Hitman


func _ready() -> void:
	print($Hitman.position)

func _process(delta: float) -> void:
	if Input.is_action_just_pressed("Reiniciar"):
		reiniciarJuego()
	pass

func reiniciarJuego():
	get_tree().reload_current_scene()
